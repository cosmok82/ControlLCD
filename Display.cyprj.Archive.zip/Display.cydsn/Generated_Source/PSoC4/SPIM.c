/*******************************************************************************
* File Name: SPIM.c
* Version 1.20
*
* Description:
*  This file provides the source code to the API for the SCB Component.
*
* Note:
*
*******************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIM_PVT.h"

#if(SPIM_SCB_MODE_I2C_INC)
    #include "SPIM_I2C_PVT.h"
#endif /* (SPIM_SCB_MODE_I2C_INC) */

#if(SPIM_SCB_MODE_EZI2C_INC)
    #include "SPIM_EZI2C_PVT.h"
#endif /* (SPIM_SCB_MODE_EZI2C_INC) */

#if(SPIM_SCB_MODE_SPI_INC || SPIM_SCB_MODE_UART_INC)
    #include "SPIM_SPI_UART_PVT.h"
#endif /* (SPIM_SCB_MODE_SPI_INC || SPIM_SCB_MODE_UART_INC) */


/***************************************
*    Run Time Configuration Vars
***************************************/

/* Stores internal component configuration for unconfigured mode */
#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common config vars */
    uint8 SPIM_scbMode = SPIM_SCB_MODE_UNCONFIG;
    uint8 SPIM_scbEnableWake;
    uint8 SPIM_scbEnableIntr;

    /* I2C config vars */
    uint8 SPIM_mode;
    uint8 SPIM_acceptAddr;

    /* SPI/UART config vars */
    volatile uint8 * SPIM_rxBuffer;
    uint8  SPIM_rxDataBits;
    uint32 SPIM_rxBufferSize;

    volatile uint8 * SPIM_txBuffer;
    uint8  SPIM_txDataBits;
    uint32 SPIM_txBufferSize;

    /* EZI2C config vars */
    uint8 SPIM_numberOfAddr;
    uint8 SPIM_subAddrSize;
#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Common SCB Vars
***************************************/

uint8 SPIM_initVar = 0u;

#if !defined (CY_REMOVE_SPIM_CUSTOM_INTR_HANDLER)
    cyisraddress SPIM_customIntrHandler = NULL;
#endif /* !defined (CY_REMOVE_SPIM_CUSTOM_INTR_HANDLER) */


/***************************************
*    Private Function Prototypes
***************************************/

static void SPIM_ScbEnableIntr(void);
static void SPIM_ScbModeStop(void);


/*******************************************************************************
* Function Name: SPIM_Init
********************************************************************************
*
* Summary:
*  Initializes the SCB component to operate in one of the selected configurations:
*  I2C, SPI, UART or EZ I2C.
*  When the configuration is set to “Unconfigured SCB”, this function does
*  not do any initialization. Use mode-specific initialization APIs instead:
*  SCB_I2CInit, SCB_SpiInit, SCB_UartInit or SCB_EzI2CInit.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SPIM_Init(void)
{
#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
    if(SPIM_SCB_MODE_UNCONFIG_RUNTM_CFG)
    {
        SPIM_initVar = 0u; /* Clear init var */
    }
    else
    {
        /* Initialization was done before call */
    }

#elif(SPIM_SCB_MODE_I2C_CONST_CFG)
    SPIM_I2CInit();

#elif(SPIM_SCB_MODE_SPI_CONST_CFG)
    SPIM_SpiInit();

#elif(SPIM_SCB_MODE_UART_CONST_CFG)
    SPIM_UartInit();

#elif(SPIM_SCB_MODE_EZI2C_CONST_CFG)
    SPIM_EzI2CInit();

#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SPIM_Enable
********************************************************************************
*
* Summary:
*  Enables the SCB component operation.
*  The SCB configuration should be not changed when the component is enabled.
*  Any configuration changes should be made after disabling the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SPIM_Enable(void)
{
#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Enable SCB block, only if it is already configured */
    if(!SPIM_SCB_MODE_UNCONFIG_RUNTM_CFG)
    {
        SPIM_CTRL_REG |= SPIM_CTRL_ENABLED;

        SPIM_ScbEnableIntr();
    }
#else
    SPIM_CTRL_REG |= SPIM_CTRL_ENABLED;

    SPIM_ScbEnableIntr();
#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: SPIM_Start
********************************************************************************
*
* Summary:
*  Invokes SCB_Init() and SCB_Enable().
*  After this function call, the component is enabled and ready for operation.
*  When configuration is set to “Unconfigured SCB”, the component must first be
*  initialized to operate in one of the following configurations: I2C, SPI, UART
*  or EZ I2C. Otherwise this function does not enable the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  SPIM_initVar - used to check initial configuration, modified
*  on first function call.
*
*******************************************************************************/
void SPIM_Start(void)
{
    if(0u == SPIM_initVar)
    {
        SPIM_Init();
        SPIM_initVar = 1u; /* Component was initialized */
    }

    SPIM_Enable();
}


/*******************************************************************************
* Function Name: SPIM_Stop
********************************************************************************
*
* Summary:
*  Disables the SCB component and its interrupt.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void SPIM_Stop(void)
{
#if(SPIM_SCB_IRQ_INTERNAL)
    SPIM_DisableInt();
#endif /* (SPIM_SCB_IRQ_INTERNAL) */

    SPIM_CTRL_REG &= (uint32) ~SPIM_CTRL_ENABLED;  /* Disable SCB block */

#if(SPIM_SCB_IRQ_INTERNAL)
    SPIM_ClearPendingInt();
#endif /* (SPIM_SCB_IRQ_INTERNAL) */

    SPIM_ScbModeStop(); /* Calls scbMode specific Stop function */
}


/*******************************************************************************
* Function Name: SPIM_SetCustomInterruptHandler
********************************************************************************
*
* Summary:
*  Registers a function to be called by the internal interrupt handler.
*  First the function that is registered is called, then the internal interrupt
*  handler performs any operations such as software buffer management functions
*  before the interrupt returns.  It is the user's responsibility not to break the
*  software buffer operations. Only one custom handler is supported, which is
*  the function provided by the most recent call.
*  At initialization time no custom handler is registered.
*
* Parameters:
*  func: Pointer to the function to register.
*        The value NULL indicates to remove the current custom interrupt
*        handler.
*
* Return:
*  None
*
*******************************************************************************/
void SPIM_SetCustomInterruptHandler(cyisraddress func)
{
#if !defined (CY_REMOVE_SPIM_CUSTOM_INTR_HANDLER)
    SPIM_customIntrHandler = func; /* Register interrupt handler */
#else
    if(NULL != func)
    {
        /* Suppress compiler warning */
    }
#endif /* !defined (CY_REMOVE_SPIM_CUSTOM_INTR_HANDLER) */
}


/*******************************************************************************
* Function Name: SPIM_ScbModeEnableIntr
********************************************************************************
*
* Summary:
*  Enables an interrupt for a specific mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void SPIM_ScbEnableIntr(void)
{
#if(SPIM_SCB_IRQ_INTERNAL)
    #if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
        /* Enable interrupt in the NVIC */
        if(0u != SPIM_scbEnableIntr)
        {
            SPIM_EnableInt();
        }
    #else
        SPIM_EnableInt();

    #endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */
#endif /* (SPIM_SCB_IRQ_INTERNAL) */
}


/*******************************************************************************
* Function Name: SPIM_ScbModeStop
********************************************************************************
*
* Summary:
*  Calls the Stop function for a specific operation mode.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
static void SPIM_ScbModeStop(void)
{
#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
    if(SPIM_SCB_MODE_I2C_RUNTM_CFG)
    {
        SPIM_I2CStop();
    }
    else if(SPIM_SCB_MODE_EZI2C_RUNTM_CFG)
    {
        SPIM_EzI2CStop();
    }
    else
    {
        /* Do nohing for other modes */
    }
#elif(SPIM_SCB_MODE_I2C_CONST_CFG)
    SPIM_I2CStop();

#elif(SPIM_SCB_MODE_EZI2C_CONST_CFG)
    SPIM_EzI2CStop();

#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
    /*******************************************************************************
    * Function Name: SPIM_SetPins
    ********************************************************************************
    *
    * Summary:
    *  Sets the pins settings accordingly to the selected operation mode.
    *  Only available in the Unconfigured operation mode. The mode specific
    *  initialization function calls it.
    *  Pins configuration is set by PSoC Creator when a specific mode of operation
    *  is selected in design time.
    *
    * Parameters:
    *  mode:      Mode of SCB operation.
    *  subMode:   Sub-mode of SCB operation. It is only required for SPI and UART
    *             modes.
    *  uartTxRx:  Direction for UART.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void SPIM_SetPins(uint32 mode, uint32 subMode, uint32 uartTxRx)
    {
        uint32 hsiomSel [SPIM_SCB_PINS_NUMBER];
        uint32 pinsDm   [SPIM_SCB_PINS_NUMBER];
        uint32 pinsInBuf = 0u;

        uint32 i;

        /* Set default HSIOM to GPIO and Drive Mode to Analog Hi-Z */
        for(i = 0u; i < SPIM_SCB_PINS_NUMBER; i++)
        {
            hsiomSel[i]  = SPIM_HSIOM_DEF_SEL;
            pinsDm[i]    = SPIM_PIN_DM_ALG_HIZ;
        }

        if((SPIM_SCB_MODE_I2C   == mode) ||
           (SPIM_SCB_MODE_EZI2C == mode))
        {
            hsiomSel[SPIM_MOSI_SCL_RX_PIN_INDEX] = SPIM_HSIOM_I2C_SEL;
            hsiomSel[SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_HSIOM_I2C_SEL;

            pinsDm[SPIM_MOSI_SCL_RX_PIN_INDEX] = SPIM_PIN_DM_OD_LO;
            pinsDm[SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_PIN_DM_OD_LO;
        }
    #if(!SPIM_CY_SCBIP_V1_I2C_ONLY)
        else if(SPIM_SCB_MODE_SPI == mode)
        {
            hsiomSel[SPIM_MOSI_SCL_RX_PIN_INDEX] = SPIM_HSIOM_SPI_SEL;
            hsiomSel[SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_HSIOM_SPI_SEL;
            hsiomSel[SPIM_SCLK_PIN_INDEX]        = SPIM_HSIOM_SPI_SEL;

            if(SPIM_SPI_SLAVE == subMode)
            {
                /* Slave */
                pinsDm[SPIM_MOSI_SCL_RX_PIN_INDEX] = SPIM_PIN_DM_DIG_HIZ;
                pinsDm[SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_PIN_DM_STRONG;
                pinsDm[SPIM_SCLK_PIN_INDEX]        = SPIM_PIN_DM_DIG_HIZ;

            #if(SPIM_SS0_PIN)
                /* Only SS0 is valid choice for Slave */
                hsiomSel[SPIM_SS0_PIN_INDEX] = SPIM_HSIOM_SPI_SEL;
                pinsDm  [SPIM_SS0_PIN_INDEX] = SPIM_PIN_DM_DIG_HIZ;
            #endif /* (SPIM_SS1_PIN) */

            #if(SPIM_MISO_SDA_TX_PIN)
                /* Disable input buffer */
                 pinsInBuf |= SPIM_MISO_SDA_TX_PIN_MASK;
            #endif /* (SPIM_MISO_SDA_TX_PIN_PIN) */
            }
            else /* (Master) */
            {
                pinsDm[SPIM_MOSI_SCL_RX_PIN_INDEX] = SPIM_PIN_DM_STRONG;
                pinsDm[SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_PIN_DM_DIG_HIZ;
                pinsDm[SPIM_SCLK_PIN_INDEX]        = SPIM_PIN_DM_STRONG;

            #if(SPIM_SS0_PIN)
                hsiomSel [SPIM_SS0_PIN_INDEX] = SPIM_HSIOM_SPI_SEL;
                pinsDm   [SPIM_SS0_PIN_INDEX] = SPIM_PIN_DM_STRONG;
                pinsInBuf                                |= SPIM_SS0_PIN_MASK;
            #endif /* (SPIM_SS0_PIN) */

            #if(SPIM_SS1_PIN)
                hsiomSel [SPIM_SS1_PIN_INDEX] = SPIM_HSIOM_SPI_SEL;
                pinsDm   [SPIM_SS1_PIN_INDEX] = SPIM_PIN_DM_STRONG;
                pinsInBuf                                |= SPIM_SS1_PIN_MASK;
            #endif /* (SPIM_SS1_PIN) */

            #if(SPIM_SS2_PIN)
                hsiomSel [SPIM_SS2_PIN_INDEX] = SPIM_HSIOM_SPI_SEL;
                pinsDm   [SPIM_SS2_PIN_INDEX] = SPIM_PIN_DM_STRONG;
                pinsInBuf                                |= SPIM_SS2_PIN_MASK;
            #endif /* (SPIM_SS2_PIN) */

            #if(SPIM_SS3_PIN)
                hsiomSel [SPIM_SS3_PIN_INDEX] = SPIM_HSIOM_SPI_SEL;
                pinsDm   [SPIM_SS3_PIN_INDEX] = SPIM_PIN_DM_STRONG;
                pinsInBuf                                |= SPIM_SS3_PIN_MASK;
            #endif /* (SPIM_SS2_PIN) */

                /* Disable input buffers */
            #if(SPIM_MOSI_SCL_RX_PIN)
                pinsInBuf |= SPIM_MOSI_SCL_RX_PIN_MASK;
            #endif /* (SPIM_MOSI_SCL_RX_PIN) */

             #if(SPIM_MOSI_SCL_RX_WAKE_PIN)
                pinsInBuf |= SPIM_MOSI_SCL_RX_WAKE_PIN_MASK;
            #endif /* (SPIM_MOSI_SCL_RX_WAKE_PIN) */

            #if(SPIM_SCLK_PIN)
                pinsInBuf |= SPIM_SCLK_PIN_MASK;
            #endif /* (SPIM_SCLK_PIN) */
            }
        }
        else /* UART */
        {
            if(SPIM_UART_MODE_SMARTCARD == subMode)
            {
                /* SmartCard */
                hsiomSel[SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_HSIOM_UART_SEL;
                pinsDm  [SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_PIN_DM_OD_LO;
            }
            else /* Standard or IrDA */
            {
                if(0u != (SPIM_UART_RX & uartTxRx))
                {
                    hsiomSel[SPIM_MOSI_SCL_RX_PIN_INDEX] = SPIM_HSIOM_UART_SEL;
                    pinsDm  [SPIM_MOSI_SCL_RX_PIN_INDEX] = SPIM_PIN_DM_DIG_HIZ;
                }

                if(0u != (SPIM_UART_TX & uartTxRx))
                {
                    hsiomSel[SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_HSIOM_UART_SEL;
                    pinsDm  [SPIM_MISO_SDA_TX_PIN_INDEX] = SPIM_PIN_DM_STRONG;

                #if(SPIM_MISO_SDA_TX_PIN)
                     pinsInBuf |= SPIM_MISO_SDA_TX_PIN_MASK;
                #endif /* (SPIM_MISO_SDA_TX_PIN_PIN) */
                }
            }
        }
    #endif /* (!SPIM_CY_SCBIP_V1_I2C_ONLY) */

    /* Configure pins: set HSIOM, DM and InputBufEnable */
    /* Note: the DR register settigns do not effect the pin output if HSIOM is other than GPIO */

    #if(SPIM_MOSI_SCL_RX_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_MOSI_SCL_RX_HSIOM_REG,
                                       SPIM_MOSI_SCL_RX_HSIOM_MASK,
                                       SPIM_MOSI_SCL_RX_HSIOM_POS,
                                       hsiomSel[SPIM_MOSI_SCL_RX_PIN_INDEX]);

        SPIM_spi_mosi_i2c_scl_uart_rx_SetDriveMode((uint8) pinsDm[SPIM_MOSI_SCL_RX_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_mosi_i2c_scl_uart_rx_INP_DIS,
                                     SPIM_spi_mosi_i2c_scl_uart_rx_MASK,
                                     (0u != (pinsInBuf & SPIM_MOSI_SCL_RX_PIN_MASK)));
    #endif /* (SPIM_MOSI_SCL_RX_PIN) */

    #if(SPIM_MOSI_SCL_RX_WAKE_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_MOSI_SCL_RX_WAKE_HSIOM_REG,
                                       SPIM_MOSI_SCL_RX_WAKE_HSIOM_MASK,
                                       SPIM_MOSI_SCL_RX_WAKE_HSIOM_POS,
                                       hsiomSel[SPIM_MOSI_SCL_RX_WAKE_PIN_INDEX]);

        SPIM_spi_mosi_i2c_scl_uart_rx_wake_SetDriveMode((uint8)
                                                               pinsDm[SPIM_MOSI_SCL_RX_WAKE_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_mosi_i2c_scl_uart_rx_wake_INP_DIS,
                                     SPIM_spi_mosi_i2c_scl_uart_rx_wake_MASK,
                                     (0u != (pinsInBuf & SPIM_MOSI_SCL_RX_WAKE_PIN_MASK)));

         /* Set interrupt on falling edge */
        SPIM_SET_INCFG_TYPE(SPIM_MOSI_SCL_RX_WAKE_INTCFG_REG,
                                        SPIM_MOSI_SCL_RX_WAKE_INTCFG_TYPE_MASK,
                                        SPIM_MOSI_SCL_RX_WAKE_INTCFG_TYPE_POS,
                                        SPIM_INTCFG_TYPE_FALLING_EDGE);
    #endif /* (SPIM_MOSI_SCL_RX_WAKE_PIN) */

    #if(SPIM_MISO_SDA_TX_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_MISO_SDA_TX_HSIOM_REG,
                                       SPIM_MISO_SDA_TX_HSIOM_MASK,
                                       SPIM_MISO_SDA_TX_HSIOM_POS,
                                       hsiomSel[SPIM_MISO_SDA_TX_PIN_INDEX]);

        SPIM_spi_miso_i2c_sda_uart_tx_SetDriveMode((uint8) pinsDm[SPIM_MISO_SDA_TX_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_miso_i2c_sda_uart_tx_INP_DIS,
                                     SPIM_spi_miso_i2c_sda_uart_tx_MASK,
                                    (0u != (pinsInBuf & SPIM_MISO_SDA_TX_PIN_MASK)));
    #endif /* (SPIM_MOSI_SCL_RX_PIN) */

    #if(SPIM_SCLK_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_SCLK_HSIOM_REG, SPIM_SCLK_HSIOM_MASK,
                                       SPIM_SCLK_HSIOM_POS, hsiomSel[SPIM_SCLK_PIN_INDEX]);

        SPIM_spi_sclk_SetDriveMode((uint8) pinsDm[SPIM_SCLK_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_sclk_INP_DIS,
                             SPIM_spi_sclk_MASK,
                            (0u != (pinsInBuf & SPIM_SCLK_PIN_MASK)));
    #endif /* (SPIM_SCLK_PIN) */

    #if(SPIM_SS0_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_SS0_HSIOM_REG, SPIM_SS0_HSIOM_MASK,
                                       SPIM_SS0_HSIOM_POS, hsiomSel[SPIM_SS0_PIN_INDEX]);

        SPIM_spi_ss0_SetDriveMode((uint8) pinsDm[SPIM_SS0_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_ss0_INP_DIS,
                                     SPIM_spi_ss0_MASK,
                                     (0u != (pinsInBuf & SPIM_SS0_PIN_MASK)));
    #endif /* (SPIM_SS1_PIN) */

    #if(SPIM_SS1_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_SS1_HSIOM_REG, SPIM_SS1_HSIOM_MASK,
                                       SPIM_SS1_HSIOM_POS, hsiomSel[SPIM_SS1_PIN_INDEX]);

        SPIM_spi_ss1_SetDriveMode((uint8) pinsDm[SPIM_SS1_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_ss1_INP_DIS,
                                     SPIM_spi_ss1_MASK,
                                     (0u != (pinsInBuf & SPIM_SS1_PIN_MASK)));
    #endif /* (SPIM_SS1_PIN) */

    #if(SPIM_SS2_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_SS2_HSIOM_REG, SPIM_SS2_HSIOM_MASK,
                                       SPIM_SS2_HSIOM_POS, hsiomSel[SPIM_SS2_PIN_INDEX]);

        SPIM_spi_ss2_SetDriveMode((uint8) pinsDm[SPIM_SS2_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_ss2_INP_DIS,
                                     SPIM_spi_ss2_MASK,
                                     (0u != (pinsInBuf & SPIM_SS2_PIN_MASK)));
    #endif /* (SPIM_SS2_PIN) */

    #if(SPIM_SS3_PIN)
        SPIM_SET_HSIOM_SEL(SPIM_SS3_HSIOM_REG,  SPIM_SS3_HSIOM_MASK,
                                       SPIM_SS3_HSIOM_POS, hsiomSel[SPIM_SS3_PIN_INDEX]);

        SPIM_spi_ss3_SetDriveMode((uint8) pinsDm[SPIM_SS3_PIN_INDEX]);

        SPIM_SET_INP_DIS(SPIM_spi_ss3_INP_DIS,
                                     SPIM_spi_ss3_MASK,
                                     (0u != (pinsInBuf & SPIM_SS3_PIN_MASK)));
    #endif /* (SPIM_SS3_PIN) */
    }

#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */


/* [] END OF FILE */
