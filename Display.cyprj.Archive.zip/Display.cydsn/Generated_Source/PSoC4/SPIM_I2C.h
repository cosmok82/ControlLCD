/*******************************************************************************
* File Name: SPIM_I2C.h
* Version 1.20
*
* Description:
*  This file provides constants and parameter values for the SCB Component in
*  I2C mode.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_I2C_SPIM_H)
#define CY_SCB_I2C_SPIM_H

#include "SPIM.h"


/***************************************
*   Initial Parameter Constants
****************************************/

#define SPIM_I2C_MODE                   (1u)
#define SPIM_I2C_OVS_FACTOR_LOW         (8u)
#define SPIM_I2C_OVS_FACTOR_HIGH        (8u)
#define SPIM_I2C_MEDIAN_FILTER_ENABLE   (1u)
#define SPIM_I2C_SLAVE_ADDRESS          (8u)
#define SPIM_I2C_SLAVE_ADDRESS_MASK     (254u)
#define SPIM_I2C_ACCEPT_ADDRESS         (0u)
#define SPIM_I2C_WAKE_ENABLE            (0u)
#define SPIM_I2C_DATA_RATE              (100u)
#define SPIM_I2C_EXTERN_INTR_HANDLER    (0u)


/***************************************
*  Conditional Compilation Parameters
****************************************/

/* I2C sub mode enum */
#define SPIM_I2C_MODE_SLAVE              (0x01u)
#define SPIM_I2C_MODE_MASTER             (0x02u)
#define SPIM_I2C_MODE_MULTI_MASTER       (0x06u)
#define SPIM_I2C_MODE_MULTI_MASTER_SLAVE (0x07u)
#define SPIM_I2C_MODE_MULTI_MASTER_MASK  (0x04u)

#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)

    /* Returns true if slave mode is enabled */
    #define SPIM_I2C_SLAVE  (0u != (SPIM_I2C_MODE_SLAVE & SPIM_mode))

    /* Returns true if master mode is enabled */
    #define SPIM_I2C_MASTER (0u != (SPIM_I2C_MODE_MASTER & SPIM_mode))

    /* Returns true if multi-master mode is enabled */
    #define SPIM_I2C_MULTI_MASTER \
                            (0u != (SPIM_I2C_MODE_MULTI_MASTER_MASK & SPIM_mode))

    /* Returns true if mode is multi-master-slave */
    #define SPIM_I2C_MULTI_MASTER_SLAVE \
                            (SPIM_I2C_MODE_MULTI_MASTER_SLAVE == SPIM_mode)

    /* Returns true if address accepts in RX FIFO */
    #define SPIM_CHECK_I2C_ACCEPT_ADDRESS   (0u != SPIM_acceptAddr)

    #define SPIM_I2C_WAKE_ENABLE_CONST          (1u)
    #define SPIM_I2C_SLAVE_CONST                (1u)
    #define SPIM_I2C_MASTER_CONST               (1u)
    #define SPIM_CHECK_I2C_ACCEPT_ADDRESS_CONST (1u)

    #define SPIM_I2C_BTLDR_COMM_ENABLED ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SPIM) || \
                                                     (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface))

#else

    /* Returns true if slave mode is enabled */
    #define SPIM_I2C_SLAVE   (0u != (SPIM_I2C_MODE_SLAVE & SPIM_I2C_MODE))

    /* Returns true if master mode is enabled */
    #define SPIM_I2C_MASTER  (0u != (SPIM_I2C_MODE_MASTER & SPIM_I2C_MODE))

    /* Returns true if multi-master mode is enabled */
    #define SPIM_I2C_MULTI_MASTER \
                                    (0u != (SPIM_I2C_MODE_MULTI_MASTER_MASK & SPIM_I2C_MODE))

    /* Returns true if mode is multi-master-slave */
    #define SPIM_I2C_MULTI_MASTER_SLAVE \
                                    (SPIM_I2C_MODE_MULTI_MASTER_SLAVE == SPIM_I2C_MODE)

    /* Returns true if address accepts in RX FIFO */
    #define SPIM_CHECK_I2C_ACCEPT_ADDRESS   (0u != SPIM_I2C_ACCEPT_ADDRESS)

    /* Returns true if wakeup on address match is enabled */
    #define SPIM_I2C_WAKE_ENABLE_CONST  (0u != SPIM_I2C_WAKE_ENABLE)

    #define SPIM_I2C_SLAVE_CONST    (SPIM_I2C_SLAVE)
    #define SPIM_I2C_MASTER_CONST   (SPIM_I2C_MASTER)
    #define SPIM_CHECK_I2C_ACCEPT_ADDRESS_CONST (SPIM_CHECK_I2C_ACCEPT_ADDRESS)

    #define SPIM_I2C_BTLDR_COMM_ENABLED     (SPIM_I2C_SLAVE_CONST && \
                                                          ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_SPIM) || \
                                                           (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface)))

#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*       Type Definitions
***************************************/

typedef struct
{
    uint32 mode;
    uint32 oversampleLow;
    uint32 oversampleHigh;
    uint32 enableMedianFilter;
    uint32 slaveAddr;
    uint32 slaveAddrMask;
    uint32 acceptAddr;
    uint32 enableWake;
} SPIM_I2C_INIT_STRUCT;


/***************************************
*        Function Prototypes
***************************************/

/* Common functions */
#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
    void SPIM_I2CInit(const SPIM_I2C_INIT_STRUCT *config);
#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */

/* I2C Master functions prototypes */
#if(SPIM_I2C_MASTER_CONST)
    /* Read and Clear status functions */
    uint32 SPIM_I2CMasterStatus(void);
    uint32 SPIM_I2CMasterClearStatus(void);

    /* Interrupt based operation functions */
    uint32 SPIM_I2CMasterWriteBuf(uint32 slaveAddress, uint8 * wrData, uint32 cnt, uint32 mode);
    uint32 SPIM_I2CMasterReadBuf(uint32 slaveAddress, uint8 * rdData, uint32 cnt, uint32 mode);
    uint32 SPIM_I2CMasterGetReadBufSize(void);
    uint32 SPIM_I2CMasterGetWriteBufSize(void);
    void   SPIM_I2CMasterClearReadBuf(void);
    void   SPIM_I2CMasterClearWriteBuf(void);

    /* Manual operation functions */
    uint32 SPIM_I2CMasterSendStart(uint32 slaveAddress, uint32 bitRnW);
    uint32 SPIM_I2CMasterSendRestart(uint32 slaveAddress, uint32 bitRnW);
    uint32 SPIM_I2CMasterSendStop(void);
    uint32 SPIM_I2CMasterWriteByte(uint32 theByte);
    uint32 SPIM_I2CMasterReadByte(uint32 ackNack);
#endif /* (SPIM_I2C_MASTER_CONST) */

/* I2C Slave functions prototypes */
#if(SPIM_I2C_SLAVE_CONST)
    /* Read and Clear status functions */
    uint32 SPIM_I2CSlaveStatus(void);
    uint32 SPIM_I2CSlaveClearReadStatus(void);
    uint32 SPIM_I2CSlaveClearWriteStatus(void);

    /* Set Slave address and mask */
    void   SPIM_I2CSlaveSetAddress(uint32 address);
    void   SPIM_I2CSlaveSetAddressMask(uint32 addressMask);

    /* Interrupt based operation functions */
    void   SPIM_I2CSlaveInitReadBuf(uint8 * rdBuf, uint32 bufSize);
    void   SPIM_I2CSlaveInitWriteBuf(uint8 * wrBuf, uint32 bufSize);
    uint32 SPIM_I2CSlaveGetReadBufSize(void);
    uint32 SPIM_I2CSlaveGetWriteBufSize(void);
    void   SPIM_I2CSlaveClearReadBuf(void);
    void   SPIM_I2CSlaveClearWriteBuf(void);
#endif /* (SPIM_I2C_SLAVE_CONST) */

CY_ISR_PROTO(SPIM_I2C_ISR);

#if defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_I2C_BTLDR_COMM_ENABLED)
    /* Bootloader physical layer functions */
    void SPIM_I2CCyBtldrCommStart(void);
    void SPIM_I2CCyBtldrCommStop (void);
    void SPIM_I2CCyBtldrCommReset(void);
    cystatus SPIM_I2CCyBtldrCommRead       (uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);
    cystatus SPIM_I2CCyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut);

    /* Size of Read/Write buffers for I2C bootloader  */
    #define SPIM_I2C_BTLDR_SIZEOF_READ_BUFFER   (64u)
    #define SPIM_I2C_BTLDR_SIZEOF_WRITE_BUFFER  (64u)
    #define SPIM_I2C_MIN_UINT16(a, b)           ( ((uint16)(a) < (uint16) (b)) ? \
                                                                    ((uint32) (a)) : ((uint32) (b)) )
    #define SPIM_WAIT_1_MS                      (1u)

#endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (SPIM_I2C_BTLDR_COMM_ENABLED) */


/***************************************
*            API Constants
***************************************/

/* I2C sub mode enum */
#define SPIM_I2C_MODE_SLAVE              (0x01u)
#define SPIM_I2C_MODE_MASTER             (0x02u)
#define SPIM_I2C_MODE_MULTI_MASTER       (0x06u)
#define SPIM_I2C_MODE_MULTI_MASTER_SLAVE (0x07u)
#define SPIM_I2C_MODE_MULTI_MASTER_MASK  (0x04u)

/* Master/Slave control constants */
#define SPIM_I2C_WRITE_XFER_MODE    (0u)    /* Write    */
#define SPIM_I2C_READ_XFER_MODE     (1u)    /* Read     */
#define SPIM_I2C_ACK_DATA           (0u)    /* Send ACK */
#define SPIM_I2C_NAK_DATA           (1u)    /* Send NAK */

/* "Mode" constants for MasterWriteBuf() or MasterReadBuf() function */
#define SPIM_I2C_MODE_COMPLETE_XFER     (0x00u)    /* Full transfer with Start and Stop       */
#define SPIM_I2C_MODE_REPEAT_START      (0x01u)    /* Begin with a ReStart instead of a Start */
#define SPIM_I2C_MODE_NO_STOP           (0x02u)    /* Complete the transfer without a Stop    */

/* Master status */
#define SPIM_I2C_MSTAT_CLEAR            ((uint16) 0x00u)   /* Clear (init) status value */

#define SPIM_I2C_MSTAT_RD_CMPLT         ((uint16) 0x01u)   /* Read complete               */
#define SPIM_I2C_MSTAT_WR_CMPLT         ((uint16) 0x02u)   /* Write complete              */
#define SPIM_I2C_MSTAT_XFER_INP         ((uint16) 0x04u)   /* Master transfer in progress */
#define SPIM_I2C_MSTAT_XFER_HALT        ((uint16) 0x08u)   /* Transfer is halted          */

#define SPIM_I2C_MSTAT_ERR_MASK         ((uint16) 0x3F0u) /* Mask for all errors                          */
#define SPIM_I2C_MSTAT_ERR_SHORT_XFER   ((uint16) 0x10u)  /* Master NAKed before end of packet            */
#define SPIM_I2C_MSTAT_ERR_ADDR_NAK     ((uint16) 0x20u)  /* Slave did not ACK                            */
#define SPIM_I2C_MSTAT_ERR_ARB_LOST     ((uint16) 0x40u)  /* Master lost arbitration during communication */
#define SPIM_I2C_MSTAT_ERR_ABORT_XFER   ((uint16) 0x80u)  /* The Slave was addressed before the Start gen */
#define SPIM_I2C_MSTAT_ERR_BUS_ERROR    ((uint16) 0x100u) /* The misplaced Start or Stop was occurred     */
#define SPIM_I2C_MSTAT_ERR_XFER         ((uint16) 0x200u) /* Error during transfer                        */

/* Master API returns */
#define SPIM_I2C_MSTR_NO_ERROR          (0x00u)  /* Function complete without error                       */
#define SPIM_I2C_MSTR_ERR_ARB_LOST      (0x01u)  /* Master lost arb: INTR_MASTER_I2C_ARB_LOST             */
#define SPIM_I2C_MSTR_ERR_LB_NAK        (0x02u)  /* Last Byte Naked: INTR_MASTER_I2C_NACK                 */
#define SPIM_I2C_MSTR_NOT_READY         (0x04u)  /* Master on the bus or Slave operation is in progress   */
#define SPIM_I2C_MSTR_BUS_BUSY          (0x08u)  /* Bus is busy, process not started                      */
#define SPIM_I2C_MSTR_ERR_ABORT_START   (0x10u)  /* Slave was addressed before master begin Start gen     */
#define SPIM_I2C_MSTR_ERR_BUS_ERR       (0x100u) /* Bus eror has: INTR_MASTER_I2C_BUS_ERROR               */

/* Slave Status Constants */
#define SPIM_I2C_SSTAT_RD_CMPLT         (0x01u)    /* Read transfer complete                       */
#define SPIM_I2C_SSTAT_RD_BUSY          (0x02u)    /* Read transfer in progress                    */
#define SPIM_I2C_SSTAT_RD_OVFL          (0x04u)    /* Read overflow: master reads above buf size   */
#define SPIM_I2C_SSTAT_RD_ERR           (0x08u)    /* Read was interrupted by misplaced Start/Stop */
#define SPIM_I2C_SSTAT_RD_MASK          (0x0Fu)    /* Read Status Mask                             */
#define SPIM_I2C_SSTAT_RD_NO_ERR        (0x00u)    /* Read no Error                                */

#define SPIM_I2C_SSTAT_WR_CMPLT         (0x10u)    /* Write transfer complete                       */
#define SPIM_I2C_SSTAT_WR_BUSY          (0x20u)    /* Write transfer in progress                    */
#define SPIM_I2C_SSTAT_WR_OVFL          (0x40u)    /* Write overflow: master writes above buf size  */
#define SPIM_I2C_SSTAT_WR_ERR           (0x80u)    /* Write was interrupted by misplaced Start/Stop */
#define SPIM_I2C_SSTAT_WR_MASK          (0xF0u)    /* Write Status Mask                             */
#define SPIM_I2C_SSTAT_WR_NO_ERR        (0x00u)    /* Write no Error                                */

#define SPIM_I2C_SSTAT_RD_CLEAR         (0x0Du)    /* Read Status clear: do not clear */
#define SPIM_I2C_SSTAT_WR_CLEAR         (0xD0u)    /* Write Status Clear */

/* Internal I2C component constants */
#define SPIM_I2C_READ_FLAG              (0x01u) /* Read flag of the Address */
#define SPIM_I2C_FIFO_SIZE              (8u)    /* Max FIFO entries for I2C */
#define SPIM_I2C_SLAVE_OVFL_RETURN      (0xFFu) /* Return by slave when overflow */


#define SPIM_I2C_RESET_ERROR            (0x01u)       /* Flag to re-enable SCB IP */


/***************************************
*     Vars with External Linkage
***************************************/

#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)
    extern const SPIM_I2C_INIT_STRUCT SPIM_configI2C;
#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*           FSM states
***************************************/

#define SPIM_I2C_FSM_EXIT_IDLE      (0x00u) /* Master and Slave are not active, need to exit to IDLE */

/* Slave mode FSM states */
#define SPIM_I2C_FSM_IDLE           (0x10u) /* Idle I2C state                */
#define SPIM_I2C_FSM_SLAVE          (0x10u) /* Slave mask for all its states */

#define SPIM_I2C_FSM_SL_WR          (0x12u) /* Slave write states */
#define SPIM_I2C_FSM_SL_RD          (0x11u) /* Slave read  states */
#define SPIM_I2C_FSM_RD             (0x01u) /* FSM slave or master read state */

/* Master mode FSM states */
#define SPIM_I2C_FSM_MASTER         (0x20u) /* Master mask for all its states */
#define SPIM_I2C_FSM_MSTR_ADDR      (0x08u) /* Master address phase           */
#define SPIM_I2C_FSM_MSTR_DATA      (0x04u) /* Master data phase              */
#define SPIM_I2C_FSM_MSTR_RD        (0x01u) /* Master read phase              */

#define SPIM_I2C_FSM_MSTR_WR_ADDR   (0x28u) /* FSM master transmit address with write          */
#define SPIM_I2C_FSM_MSTR_RD_ADDR   (0x29u) /* FSM master transmit address with read           */
#define SPIM_I2C_FSM_MSTR_WR_DATA   (0x24u) /* FSM master writes data into the slave           */
#define SPIM_I2C_FSM_MSTR_RD_DATA   (0x25u) /* FSM master reads data from the slave            */
#define SPIM_I2C_FSM_MSTR_HALT      (0x60u) /* FSM master halt state: wait for Stop or ReStart */

/* Request to complete any on-going transfer */
#define SPIM_I2C_CMPLT_ANY_TRANSFER     (0x01u)

/* Returns true if FSM is in any Master state */
#define SPIM_CHECK_I2C_FSM_MASTER   (0u != (SPIM_I2C_FSM_MASTER & SPIM_state))

/* Returns true if FSM is in any Slave state */
#define SPIM_CHECK_I2C_FSM_SLAVE    (0u != (SPIM_I2C_FSM_SLAVE  & SPIM_state))

/* Returns true if FSM is in Master send address state */
#define SPIM_CHECK_I2C_FSM_ADDR (0u != (SPIM_I2C_FSM_MSTR_ADDR & SPIM_state))

/* Returns true if FSM is in Master send or receive data state */
#define SPIM_CHECK_I2C_FSM_DATA (0u != (SPIM_I2C_FSM_MSTR_DATA  & SPIM_state))

/* Returns true if FSM is in any of read states: applied for Slave and Master */
#define SPIM_CHECK_I2C_FSM_RD   (0u != (SPIM_I2C_FSM_RD  & SPIM_state))

/* Returns true if FSM is in IDLE state */
#define SPIM_CHECK_I2C_FSM_IDLE (SPIM_I2C_FSM_IDLE == SPIM_state)

/* Returns true if FSM is HALT state */
#define SPIM_CHECK_I2C_FSM_HALT (SPIM_I2C_FSM_MSTR_HALT == SPIM_state)

/* Set Master read or write completion depends on state */
#define SPIM_GET_I2C_MSTAT_CMPLT (SPIM_CHECK_I2C_FSM_RD ?           \
                                                    (SPIM_I2C_MSTAT_RD_CMPLT) : \
                                                    (SPIM_I2C_MSTAT_WR_CMPLT))


/***************************************
*       Macro Definitions
***************************************/

/* Return TRUE if sourceMask is set in SPIM_I2C_MASTER_CMD_REG: used to check if Start was generated */
#define SPIM_CHECK_I2C_MASTER_CMD(sourceMask)   (0u != (SPIM_I2C_MASTER_CMD_REG & (sourceMask)))

/* Return TRUE if SPIM_MODE_NO_STOP is set in SPIM_mstrControl: used to detect NoStop cond */
#define SPIM_CHECK_I2C_MODE_NO_STOP(mode)   (0u != (SPIM_I2C_MODE_NO_STOP & (mode)))

/* Return TRUE if SPIM_MODE_REPEAT_START is set: used to detect when generate ReStart condition */
#define SPIM_CHECK_I2C_MODE_RESTART(mode)   (0u != (SPIM_I2C_MODE_REPEAT_START  & (mode)))

/* Return TRUE if SPIM_state is in one of master states */
#define SPIM_CHECK_I2C_MASTER_ACTIVE    (SPIM_CHECK_I2C_FSM_MASTER)


/***************************************
*      Common Register Settings
***************************************/

#define SPIM_CTRL_I2C       (SPIM_CTRL_MODE_I2C)

#define SPIM_I2C_CTRL       (SPIM_I2C_CTRL_S_GENERAL_IGNORE)

#define SPIM_I2C_RX_CTRL    ((SPIM_FIFO_SIZE - 1u)  | \
                                         SPIM_RX_CTRL_MSB_FIRST | \
                                         SPIM_RX_CTRL_ENABLED)

#define SPIM_I2C_TX_CTRL    ((SPIM_FIFO_SIZE - 1u)  | \
                                         SPIM_TX_CTRL_MSB_FIRST | \
                                         SPIM_TX_CTRL_ENABLED)

#define SPIM_I2C_INTR_SLAVE_MASK    (SPIM_INTR_SLAVE_I2C_ADDR_MATCH | \
                                                 SPIM_INTR_SLAVE_I2C_NACK       | \
                                                 SPIM_INTR_SLAVE_I2C_WRITE_STOP | \
                                                 SPIM_INTR_SLAVE_I2C_BUS_ERROR  | \
                                                 SPIM_INTR_SLAVE_I2C_ARB_LOST)

#define SPIM_I2C_INTR_MASTER_MASK   (SPIM_INTR_MASTER_I2C_ARB_LOST | \
                                                 SPIM_INTR_MASTER_I2C_NACK     | \
                                                 SPIM_INTR_MASTER_I2C_STOP     | \
                                                 SPIM_INTR_MASTER_I2C_BUS_ERROR)

/* Calculates tLOW in uS units */
#define SPIM_I2C_TLOW_TIME  ((1000u / SPIM_I2C_DATA_RATE) + \
                                            ((0u != (1000u % SPIM_I2C_DATA_RATE)) ? (1u) : (0u)))
/* tHIGH = tLOW */
#define SPIM_I2C_THIGH_TIME (SPIM_I2C_TLOW_TIME)

#define SPIM_I2C_SCL_LOW    (0u)
#define SPIM_I2C_SCL_HIGH   (1u)


/***************************************
*    Initialization Register Settings
***************************************/

#if(SPIM_SCB_MODE_I2C_CONST_CFG)

    #define SPIM_I2C_MODE_MASKED    (SPIM_I2C_MODE & \
                                                (SPIM_I2C_MODE_SLAVE | SPIM_I2C_MODE_MASTER))

    #define SPIM_I2C_DEFAULT_CTRL \
                                (SPIM_GET_CTRL_ADDR_ACCEPT(SPIM_I2C_ACCEPT_ADDRESS) | \
                                 SPIM_GET_CTRL_EC_AM_MODE (SPIM_I2C_WAKE_ENABLE))

    #define SPIM_I2C_DEFAULT_I2C_CTRL \
                                (SPIM_GET_I2C_CTRL_HIGH_PHASE_OVS(SPIM_I2C_OVS_FACTOR_HIGH) | \
                                 SPIM_GET_I2C_CTRL_LOW_PHASE_OVS (SPIM_I2C_OVS_FACTOR_LOW)  | \
                                 SPIM_GET_I2C_CTRL_SL_MSTR_MODE  (SPIM_I2C_MODE_MASKED)     | \
                                 SPIM_I2C_CTRL)

    #define SPIM_I2C_DEFAULT_RX_MATCH ((SPIM_I2C_SLAVE) ? \
                                (SPIM_GET_I2C_8BIT_ADDRESS(SPIM_I2C_SLAVE_ADDRESS) | \
                                 SPIM_GET_RX_MATCH_MASK   (SPIM_I2C_SLAVE_ADDRESS_MASK)) : (0u))

    #define SPIM_I2C_DEFAULT_RX_CTRL \
                                (SPIM_GET_RX_CTRL_MEDIAN(SPIM_I2C_MEDIAN_FILTER_ENABLE) | \
                                 SPIM_I2C_RX_CTRL)

    #define SPIM_I2C_DEFAULT_TX_CTRL  (SPIM_I2C_TX_CTRL)

    #define SPIM_I2C_DEFAULT_RX_FIFO_CTRL (0u)
    #define SPIM_I2C_DEFAULT_TX_FIFO_CTRL (0u)

    /* Interrupt sources */
    #define SPIM_I2C_DEFAULT_INTR_I2C_EC_MASK   (SPIM_NO_INTR_SOURCES)
    #define SPIM_I2C_DEFAULT_INTR_SPI_EC_MASK   (SPIM_NO_INTR_SOURCES)
    #define SPIM_I2C_DEFAULT_INTR_RX_MASK       (SPIM_NO_INTR_SOURCES)
    #define SPIM_I2C_DEFAULT_INTR_TX_MASK       (SPIM_NO_INTR_SOURCES)

    #define SPIM_I2C_DEFAULT_INTR_SLAVE_MASK    ((SPIM_I2C_SLAVE) ? \
                                                                (SPIM_I2C_INTR_SLAVE_MASK) : (0u))

    #define SPIM_I2C_DEFAULT_INTR_MASTER_MASK   ((SPIM_I2C_MASTER) ? \
                                                                (SPIM_I2C_INTR_MASTER_MASK) : (0u))

#endif /* (SPIM_SCB_MODE_I2C_CONST_CFG) */

#endif /* (CY_SCB_I2C_SPIM_H) */


/* [] END OF FILE */
