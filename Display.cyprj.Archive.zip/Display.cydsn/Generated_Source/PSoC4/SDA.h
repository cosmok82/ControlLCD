/*******************************************************************************
* File Name: SDA.h  
* Version 2.0
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SDA_H) /* Pins SDA_H */
#define CY_PINS_SDA_H

#include "cytypes.h"
#include "cyfitter.h"
#include "SDA_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    SDA_Write(uint8 value) ;
void    SDA_SetDriveMode(uint8 mode) ;
uint8   SDA_ReadDataReg(void) ;
uint8   SDA_Read(void) ;
uint8   SDA_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define SDA_DRIVE_MODE_BITS        (3)
#define SDA_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - SDA_DRIVE_MODE_BITS))
#define SDA_DRIVE_MODE_SHIFT       (0x00u)
#define SDA_DRIVE_MODE_MASK        (0x07u << SDA_DRIVE_MODE_SHIFT)

#define SDA_DM_ALG_HIZ         (0x00u << SDA_DRIVE_MODE_SHIFT)
#define SDA_DM_DIG_HIZ         (0x01u << SDA_DRIVE_MODE_SHIFT)
#define SDA_DM_RES_UP          (0x02u << SDA_DRIVE_MODE_SHIFT)
#define SDA_DM_RES_DWN         (0x03u << SDA_DRIVE_MODE_SHIFT)
#define SDA_DM_OD_LO           (0x04u << SDA_DRIVE_MODE_SHIFT)
#define SDA_DM_OD_HI           (0x05u << SDA_DRIVE_MODE_SHIFT)
#define SDA_DM_STRONG          (0x06u << SDA_DRIVE_MODE_SHIFT)
#define SDA_DM_RES_UPDWN       (0x07u << SDA_DRIVE_MODE_SHIFT)

/* Digital Port Constants */
#define SDA_MASK               SDA__MASK
#define SDA_SHIFT              SDA__SHIFT
#define SDA_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define SDA_PS                     (* (reg32 *) SDA__PS)
/* Port Configuration */
#define SDA_PC                     (* (reg32 *) SDA__PC)
/* Data Register */
#define SDA_DR                     (* (reg32 *) SDA__DR)
/* Input Buffer Disable Override */
#define SDA_INP_DIS                (* (reg32 *) SDA__PC2)


#if defined(SDA__INTSTAT)  /* Interrupt Registers */

    #define SDA_INTSTAT                (* (reg32 *) SDA__INTSTAT)

#endif /* Interrupt Registers */

#endif /* End Pins SDA_H */


/* [] END OF FILE */
