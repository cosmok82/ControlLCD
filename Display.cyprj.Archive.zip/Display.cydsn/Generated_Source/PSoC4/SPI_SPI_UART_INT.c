/*******************************************************************************
* File Name: SPI_SPI_UART_INT.c
* Version 1.20
*
* Description:
*  This file provides the source code to the Interrupt Service Routine for
*  the SCB Component in SPI and UART modes.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPI_PVT.h"
#include "SPI_SPI_UART_PVT.h"


/*******************************************************************************
* Function Name: SPI_SPI_UART_ISR
********************************************************************************
*
* Summary:
*  Handles the Interrupt Service Routine for the SCB SPI or UART modes.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
CY_ISR(SPI_SPI_UART_ISR)
{
#if(SPI_INTERNAL_RX_SW_BUFFER_CONST)
    uint32 locHead;
    uint32 dataRx;
#endif /* (SPI_INTERNAL_RX_SW_BUFFER_CONST) */

#if(SPI_INTERNAL_TX_SW_BUFFER_CONST)
    uint32 locTail;
#endif /* (SPI_INTERNAL_TX_SW_BUFFER_CONST) */

    if(NULL != SPI_customIntrHandler)
    {
        SPI_customIntrHandler();
    }

    #if(SPI_CHECK_SPI_WAKE_ENABLE)
    {
        /* Clear SPI wakeup source */
        SPI_ClearSpiExtClkInterruptSource(SPI_INTR_SPI_EC_WAKE_UP);
    }
    #endif

    #if(SPI_CHECK_RX_SW_BUFFER)
    {
        if(SPI_CHECK_INTR_RX_MASKED(SPI_INTR_RX_NOT_EMPTY))
        {
            while(0u != SPI_GET_RX_FIFO_ENTRIES)
            {
                /* Get data from RX FIFO */
                dataRx = SPI_RX_FIFO_RD_REG;

                /* Move local head index */
                locHead = (SPI_rxBufferHead + 1u);

                /* Adjust local head index */
                if(SPI_RX_BUFFER_SIZE == locHead)
                {
                    locHead = 0u;
                }

                if(locHead == SPI_rxBufferTail)
                {
                    /* Overflow: through away new data */
                    SPI_rxBufferOverflow = (uint8) SPI_INTR_RX_OVERFLOW;
                }
                else
                {
                    /* Store received data */
                    SPI_PutWordInRxBuffer(locHead, dataRx);

                    /* Move head index */
                    SPI_rxBufferHead = locHead;
                }
            }

            SPI_ClearRxInterruptSource(SPI_INTR_RX_NOT_EMPTY);
        }
    }
    #endif


    #if(SPI_CHECK_TX_SW_BUFFER)
    {
        if(SPI_CHECK_INTR_TX_MASKED(SPI_INTR_TX_NOT_FULL))
        {
            /* Put data into TX FIFO */
            while(SPI_FIFO_SIZE != SPI_GET_TX_FIFO_ENTRIES)
            {
                /* Check for a room in TX software buffer */
                if(SPI_txBufferHead != SPI_txBufferTail)
                {
                    /* Move local tail index */
                    locTail = (SPI_txBufferTail + 1u);

                    /* Adjust local tail index */
                    if(SPI_TX_BUFFER_SIZE == locTail)
                    {
                        locTail = 0u;
                    }

                    /* Put data into TX FIFO */
                    SPI_TX_FIFO_WR_REG = SPI_GetWordFromTxBuffer(locTail);

                    /* Move tail index */
                    SPI_txBufferTail = locTail;
                }
                else
                {
                    /* TX software buffer is empty: complete transmition */
                    SPI_DISABLE_INTR_TX(SPI_INTR_TX_NOT_FULL);
                    break;
                }
            }

            SPI_ClearTxInterruptSource(SPI_INTR_TX_NOT_FULL);
        }
    }
    #endif
}


/* [] END OF FILE */
