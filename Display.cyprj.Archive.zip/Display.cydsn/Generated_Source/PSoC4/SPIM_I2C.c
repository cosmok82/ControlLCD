/*******************************************************************************
* File Name: SPIM_I2C.c
* Version 1.20
*
* Description:
*  This file provides the source code to the API for the SCB Component in
*  I2C mode.
*
* Note:
*
*******************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "SPIM_PVT.h"
#include "SPIM_I2C_PVT.h"


/***************************************
*      I2C Private Vars
***************************************/

volatile uint8 SPIM_state;  /* Current state of I2C FSM */


#if(SPIM_SCB_MODE_UNCONFIG_CONST_CFG)

    /***************************************
    *  Config Structure Initialization
    ***************************************/

    /* Constant configuration of I2C */
    const SPIM_I2C_INIT_STRUCT SPIM_configI2C =
    {
        SPIM_I2C_MODE,
        SPIM_I2C_OVS_FACTOR_LOW,
        SPIM_I2C_OVS_FACTOR_HIGH,
        SPIM_I2C_MEDIAN_FILTER_ENABLE,
        SPIM_I2C_SLAVE_ADDRESS,
        SPIM_I2C_SLAVE_ADDRESS_MASK,
        SPIM_I2C_ACCEPT_ADDRESS,
        SPIM_I2C_WAKE_ENABLE
    };

    /*******************************************************************************
    * Function Name: SPIM_I2CInit
    ********************************************************************************
    *
    * Summary:
    *  Configures the SCB for I2C operation.
    *
    * Parameters:
    *  config:  Pointer to a structure that contains the following ordered list of
    *           fields. These fields match the selections available in the
    *           customizer.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void SPIM_I2CInit(const SPIM_I2C_INIT_STRUCT *config)
    {
        if(NULL == config)
        {
            CYASSERT(0u != 0u); /* Halt execution due bad function parameter */
        }
        else
        {
            /* Configure pins */
            SPIM_SetPins(SPIM_SCB_MODE_I2C, SPIM_DUMMY_PARAM,
                                                                    SPIM_DUMMY_PARAM);

            /* Store internal configuration */
            SPIM_scbMode       = (uint8) SPIM_SCB_MODE_I2C;
            SPIM_scbEnableWake = (uint8) config->enableWake;
            SPIM_scbEnableIntr = (uint8) SPIM_SCB_IRQ_INTERNAL;

            SPIM_mode          = (uint8) config->mode;
            SPIM_acceptAddr    = (uint8) config->acceptAddr;

            /* Configure I2C interface */
            SPIM_CTRL_REG     = SPIM_GET_CTRL_ADDR_ACCEPT(config->acceptAddr) |
                                            SPIM_GET_CTRL_EC_AM_MODE (config->enableWake);

            SPIM_I2C_CTRL_REG = SPIM_GET_I2C_CTRL_HIGH_PHASE_OVS(config->oversampleHigh) |
                                            SPIM_GET_I2C_CTRL_LOW_PHASE_OVS (config->oversampleLow)  |
                                            SPIM_GET_I2C_CTRL_SL_MSTR_MODE  (config->mode)           |
                                            SPIM_I2C_CTRL;

        #if(SPIM_CY_SCBIP_V0)
            /* Adjust SDA filter settings. Ticket ID#150521 */
            SPIM_SET_I2C_CFG_SDA_FILT_TRIM(SPIM_EC_AM_I2C_CFG_SDA_FILT_TRIM);
        #endif /* (SPIM_CY_SCBIP_V0) */

            /* Configure RX direction */
            SPIM_RX_CTRL_REG      = SPIM_GET_RX_CTRL_MEDIAN(config->enableMedianFilter) |
                                                SPIM_I2C_RX_CTRL;
            SPIM_RX_FIFO_CTRL_REG = SPIM_CLEAR_REG;

            /* Set default address and mask */
            SPIM_RX_MATCH_REG    = ((SPIM_I2C_SLAVE) ?
                                                (SPIM_GET_I2C_8BIT_ADDRESS(config->slaveAddr) |
                                                 SPIM_GET_RX_MATCH_MASK(config->slaveAddrMask)) :
                                                (SPIM_CLEAR_REG));


            /* Configure TX direction */
            SPIM_TX_CTRL_REG      = SPIM_I2C_TX_CTRL;
            SPIM_TX_FIFO_CTRL_REG = SPIM_CLEAR_REG;

            /* Configure interrupt with I2C handler but do not enable it */
            CyIntDisable    (SPIM_ISR_NUMBER);
            CyIntSetPriority(SPIM_ISR_NUMBER, SPIM_ISR_PRIORITY);
            (void) CyIntSetVector(SPIM_ISR_NUMBER, &SPIM_I2C_ISR);

            /* Configure interrupt sources */
        #if(!SPIM_CY_SCBIP_V1_I2C_ONLY)
            SPIM_INTR_SPI_EC_MASK_REG = SPIM_NO_INTR_SOURCES;
        #endif /* (!SPIM_CY_SCBIP_V1_I2C_ONLY) */

            SPIM_INTR_I2C_EC_MASK_REG = SPIM_NO_INTR_SOURCES;
            SPIM_INTR_RX_MASK_REG     = SPIM_NO_INTR_SOURCES;
            SPIM_INTR_TX_MASK_REG     = SPIM_NO_INTR_SOURCES;

            SPIM_INTR_SLAVE_MASK_REG  = ((SPIM_I2C_SLAVE) ?
                                                     (SPIM_I2C_INTR_SLAVE_MASK) :
                                                     (SPIM_CLEAR_REG));

            SPIM_INTR_MASTER_MASK_REG = ((SPIM_I2C_MASTER) ?
                                                     (SPIM_I2C_INTR_MASTER_MASK) :
                                                     (SPIM_CLEAR_REG));

            /* Configure global variables */
            SPIM_state = SPIM_I2C_FSM_IDLE;

            /* Internal slave variables */
            SPIM_slStatus        = 0u;
            SPIM_slRdBufIndex    = 0u;
            SPIM_slWrBufIndex    = 0u;
            SPIM_slOverFlowCount = 0u;

            /* Internal master variables */
            SPIM_mstrStatus     = 0u;
            SPIM_mstrRdBufIndex = 0u;
            SPIM_mstrWrBufIndex = 0u;
        }
    }

#else

    /*******************************************************************************
    * Function Name: SPIM_I2CInit
    ********************************************************************************
    *
    * Summary:
    *  Configures the SCB for the I2C operation.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void SPIM_I2CInit(void)
    {
        /* Configure I2C interface */
        SPIM_CTRL_REG     = SPIM_I2C_DEFAULT_CTRL;
        SPIM_I2C_CTRL_REG = SPIM_I2C_DEFAULT_I2C_CTRL;

    #if(SPIM_CY_SCBIP_V0)
        /* Adjust SDA filter settings. Ticket ID#150521 */
        SPIM_SET_I2C_CFG_SDA_FILT_TRIM(SPIM_EC_AM_I2C_CFG_SDA_FILT_TRIM);
    #endif /* (SPIM_CY_SCBIP_V0) */

        /* Configure RX direction */
        SPIM_RX_CTRL_REG      = SPIM_I2C_DEFAULT_RX_CTRL;
        SPIM_RX_FIFO_CTRL_REG = SPIM_I2C_DEFAULT_RX_FIFO_CTRL;

        /* Set default address and mask */
        SPIM_RX_MATCH_REG     = SPIM_I2C_DEFAULT_RX_MATCH;

        /* Configure TX direction */
        SPIM_TX_CTRL_REG      = SPIM_I2C_DEFAULT_TX_CTRL;
        SPIM_TX_FIFO_CTRL_REG = SPIM_I2C_DEFAULT_TX_FIFO_CTRL;

        /* Configure interrupt with I2C handler but do not enable it */
        CyIntDisable    (SPIM_ISR_NUMBER);
        CyIntSetPriority(SPIM_ISR_NUMBER, SPIM_ISR_PRIORITY);
    #if(!SPIM_I2C_EXTERN_INTR_HANDLER)
        (void) CyIntSetVector(SPIM_ISR_NUMBER, &SPIM_I2C_ISR);
    #endif /* (SPIM_I2C_EXTERN_INTR_HANDLER) */

        /* Configure interrupt sources */
    #if(!SPIM_CY_SCBIP_V1_I2C_ONLY)
        SPIM_INTR_SPI_EC_MASK_REG = SPIM_I2C_DEFAULT_INTR_SPI_EC_MASK;
    #endif /* (!SPIM_CY_SCBIP_V1_I2C_ONLY) */

        SPIM_INTR_I2C_EC_MASK_REG = SPIM_I2C_DEFAULT_INTR_I2C_EC_MASK;
        SPIM_INTR_SLAVE_MASK_REG  = SPIM_I2C_DEFAULT_INTR_SLAVE_MASK;
        SPIM_INTR_MASTER_MASK_REG = SPIM_I2C_DEFAULT_INTR_MASTER_MASK;
        SPIM_INTR_RX_MASK_REG     = SPIM_I2C_DEFAULT_INTR_RX_MASK;
        SPIM_INTR_TX_MASK_REG     = SPIM_I2C_DEFAULT_INTR_TX_MASK;

        /* Configure global variables */
        SPIM_state = SPIM_I2C_FSM_IDLE;

    #if(SPIM_I2C_SLAVE)
        /* Internal slave variable */
        SPIM_slStatus        = 0u;
        SPIM_slRdBufIndex    = 0u;
        SPIM_slWrBufIndex    = 0u;
        SPIM_slOverFlowCount = 0u;
    #endif /* (SPIM_I2C_SLAVE) */

    #if(SPIM_I2C_MASTER)
    /* Internal master variable */
        SPIM_mstrStatus     = 0u;
        SPIM_mstrRdBufIndex = 0u;
        SPIM_mstrWrBufIndex = 0u;
    #endif /* (SPIM_I2C_MASTER) */
    }
#endif /* (SPIM_SCB_MODE_UNCONFIG_CONST_CFG) */


/*******************************************************************************
* Function Name: SPIM_I2CStop
********************************************************************************
*
* Summary:
*  Resets the I2C FSM into the default state and disables TX interrupt sources.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*
*
*******************************************************************************/
void SPIM_I2CStop(void)
{
    /* Disable TX interrupt sources in order not to cause a false trigger.
    * The incoming transaction will enable an appropriate TX interrupt.
    */
    SPIM_SetTxInterruptMode(SPIM_NO_INTR_SOURCES);

#if(SPIM_CY_SCBIP_V0)
    /* Clear pending interrupt as TX FIFO becomes empty and block does not gate interrupt trigger when disabled */
    SPIM_ClearPendingInt();
#endif /* (SPIM_CY_SCBIP_V0) */

    SPIM_state = SPIM_I2C_FSM_IDLE;
}


#if(SPIM_I2C_WAKE_ENABLE_CONST)
    /*******************************************************************************
    * Function Name: SPIM_I2CSaveConfig
    ********************************************************************************
    *
    * Summary:
    *  Enables SPIM_INTR_I2C_EC_WAKE_UP interrupt source. This interrupt
    *  triggers on address match and wakes up device.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void SPIM_I2CSaveConfig(void)
    {
        SPIM_SetI2CExtClkInterruptMode(SPIM_INTR_I2C_EC_WAKE_UP);
    }


    /*******************************************************************************
    * Function Name: SPIM_I2CRestoreConfig
    ********************************************************************************
    *
    * Summary:
    *  Added for compatibility.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void SPIM_I2CRestoreConfig(void)
    {
        /* SPIM_INTR_I2C_EC_WAKE_UP is masked-off in the interrupt */
    }
#endif /* (SPIM_I2C_WAKE_ENABLE_CONST) */


/* [] END OF FILE */
