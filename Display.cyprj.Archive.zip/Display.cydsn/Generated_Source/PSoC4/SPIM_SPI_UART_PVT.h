/*******************************************************************************
* File Name: SPIM_SPI_UART_PVT.h
* Version 1.20
*
* Description:
*  This private file provides constants and parameter values for the
*  SCB Component in SPI and UART modes.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_SPI_UART_PVT_SPIM_H)
#define CY_SCB_SPI_UART_PVT_SPIM_H

#include "SPIM_SPI_UART.h"


/***************************************
*     Internal Global Vars
***************************************/

#if(SPIM_INTERNAL_RX_SW_BUFFER_CONST)
    extern volatile uint32  SPIM_rxBufferHead;
    extern volatile uint32  SPIM_rxBufferTail;
    extern volatile uint8   SPIM_rxBufferOverflow;
#endif /* (SPIM_INTERNAL_RX_SW_BUFFER_CONST) */

#if(SPIM_INTERNAL_TX_SW_BUFFER_CONST)
    extern volatile uint32  SPIM_txBufferHead;
    extern volatile uint32  SPIM_txBufferTail;
#endif /* (SPIM_INTERNAL_TX_SW_BUFFER_CONST) */

#if(SPIM_INTERNAL_RX_SW_BUFFER)
    extern volatile uint8 SPIM_rxBufferInternal[SPIM_RX_BUFFER_SIZE];
#endif /* (SPIM_INTERNAL_RX_SW_BUFFER) */

#if(SPIM_INTERNAL_TX_SW_BUFFER)
    extern volatile uint8 SPIM_txBufferInternal[SPIM_TX_BUFFER_SIZE];
#endif /* (SPIM_INTERNAL_TX_SW_BUFFER) */


/***************************************
*     Private Function Prototypes
***************************************/

#if(SPIM_SCB_MODE_SPI_CONST_CFG)
    void SPIM_SpiInit(void);
#endif /* (SPIM_SCB_MODE_SPI_CONST_CFG) */

#if(SPIM_SPI_WAKE_ENABLE_CONST)
    void SPIM_SpiSaveConfig(void);
    void SPIM_SpiRestoreConfig(void);
#endif /* (SPIM_SPI_WAKE_ENABLE_CONST) */

#if(SPIM_SCB_MODE_UART_CONST_CFG)
    void SPIM_UartInit(void);
#endif /* (SPIM_SCB_MODE_UART_CONST_CFG) */

#if(SPIM_UART_WAKE_ENABLE_CONST)
    void SPIM_UartSaveConfig(void);
    void SPIM_UartRestoreConfig(void);
#endif /* (SPIM_UART_WAKE_ENABLE_CONST) */

/* Interrupt processing */
#define SPIM_SpiUartEnableIntRx(intSourceMask)  SPIM_SetRxInterruptMode(intSourceMask)
#define SPIM_SpiUartEnableIntTx(intSourceMask)  SPIM_SetTxInterruptMode(intSourceMask)
uint32  SPIM_SpiUartDisableIntRx(void);
uint32  SPIM_SpiUartDisableIntTx(void);

#endif /* (CY_SCB_SPI_UART_PVT_SPIM_H) */


/* [] END OF FILE */
