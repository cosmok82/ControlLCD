/*******************************************************************************
* File Name: ClockSPI.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_ClockSPI_H)
#define CY_CLOCK_ClockSPI_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void ClockSPI_StartEx(uint32 alignClkDiv);
#define ClockSPI_Start() \
    ClockSPI_StartEx(ClockSPI__PA_DIV_ID)

#else

void ClockSPI_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void ClockSPI_Stop(void);

void ClockSPI_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 ClockSPI_GetDividerRegister(void);
uint8  ClockSPI_GetFractionalDividerRegister(void);

#define ClockSPI_Enable()                         ClockSPI_Start()
#define ClockSPI_Disable()                        ClockSPI_Stop()
#define ClockSPI_SetDividerRegister(clkDivider, reset)  \
    ClockSPI_SetFractionalDividerRegister((clkDivider), 0u)
#define ClockSPI_SetDivider(clkDivider)           ClockSPI_SetDividerRegister((clkDivider), 1u)
#define ClockSPI_SetDividerValue(clkDivider)      ClockSPI_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define ClockSPI_DIV_ID     ClockSPI__DIV_ID

#define ClockSPI_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define ClockSPI_CTRL_REG   (*(reg32 *)ClockSPI__CTRL_REGISTER)
#define ClockSPI_DIV_REG    (*(reg32 *)ClockSPI__DIV_REGISTER)

#define ClockSPI_CMD_DIV_SHIFT          (0u)
#define ClockSPI_CMD_PA_DIV_SHIFT       (8u)
#define ClockSPI_CMD_DISABLE_SHIFT      (30u)
#define ClockSPI_CMD_ENABLE_SHIFT       (31u)

#define ClockSPI_CMD_DISABLE_MASK       ((uint32)((uint32)1u << ClockSPI_CMD_DISABLE_SHIFT))
#define ClockSPI_CMD_ENABLE_MASK        ((uint32)((uint32)1u << ClockSPI_CMD_ENABLE_SHIFT))

#define ClockSPI_DIV_FRAC_MASK  (0x000000F8u)
#define ClockSPI_DIV_FRAC_SHIFT (3u)
#define ClockSPI_DIV_INT_MASK   (0xFFFFFF00u)
#define ClockSPI_DIV_INT_SHIFT  (8u)

#else 

#define ClockSPI_DIV_REG        (*(reg32 *)ClockSPI__REGISTER)
#define ClockSPI_ENABLE_REG     ClockSPI_DIV_REG
#define ClockSPI_DIV_FRAC_MASK  ClockSPI__FRAC_MASK
#define ClockSPI_DIV_FRAC_SHIFT (16u)
#define ClockSPI_DIV_INT_MASK   ClockSPI__DIVIDER_MASK
#define ClockSPI_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_ClockSPI_H) */

/* [] END OF FILE */
