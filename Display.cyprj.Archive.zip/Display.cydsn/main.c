/******************************************************************************
* Author            : Orlando Cosimo
* Project Name		: SPI S6D02A1\ST7735 - Display TFTM1802
* File Name			: main.c
* Version 			: beta 1.1
* Device Used		: CY8C4245AXI-483
* Software Used		: PSoC Creator 3.0
* Compiler    		: ARMGCC 4.7.3, ARM RVDS Generic, ARM MDK Generic
* Related Hardware	: CY8CKIT-049-42xx PSoC 4 Prototyping Kit 
*******************************************************************************
*
*  Description:
*   Provides a demo of SPI LCD Library functionality on a display TFTM1802
*   (S6D02A1\ST7735), tested with the board CY8CKIT-049-42xx.
*
******************************************************************************/

#include <project.h>
#include "ControlLCD.h"

uint8_t x_start, y_start;
char text[]  = "Ahi quanto a dir\nqual era e' cosa dura, esta selva selvaggia e aspra e forte, che nel pensier rinova la paura!";
uint8_t font_dim = 1;

int main()
{   
	PWM_Start();
    CyDelay(500);
    
    initDISPLAY(); // initializes LCD
    
	for(;;) // Demo
    {
        int i;
        
        fillScreen(BLACK);
        
        // circles demo
        for(i = 0; i < getHeight(); i += 2)
        {
            drawCircle(getWidth()/2, getHeight()/2, i, RED);
            CyDelay(10);
        }
        CyDelay(250);
        fillScreen(RED);
        CyDelay(1000);
        fillScreen(BLACK);
        
        // lines demo
        for(i = 0; i < getHeight(); i += 2)
        {   drawFastHLine(0, i, getWidth(), WHITE);
            CyDelay(10);
        }
        CyDelay(250);
        for(i = 0; i < getWidth(); i += 2)
        {
            drawFastVLine(i, 0, getHeight(), WHITE);
            CyDelay(10);
        }
        CyDelay(250);
        fillScreen(WHITE);
        CyDelay(1000);
        fillScreen(BLACK);
        
        // rectangles demo
        for(i = 0; i < getWidth()/2; i += 2)
        {
            drawRect(i, i+(HEIGHT-WIDTH)/2, getWidth()-i*2, getWidth()-i*2, BLUE);
            CyDelay(10);
        }
        CyDelay(250);
        fillScreen(BLUE);
        CyDelay(1000);
        fillScreen(BLACK);
        
        // round corners rectangles demo
        for(i = (getWidth()/2)-20; i > 0; i -= 2)
        {
            fillRoundRect(i, i+(HEIGHT-WIDTH)/2, getWidth()-i*2, getWidth()-i*2, 20, GREEN);
            CyDelay(10);
        }
        CyDelay(1000);
        fillScreen(BLACK);
        
        // RGB colors demos
        for(i = 42; i > 0; i--)
        {
            drawFastVLine(i+84, 0, getHeight(), ((i*0x3F) << (16+2)) );
            drawFastVLine(i+42, 0, getHeight(), ((i*0x3F) << (8+2))  );
            drawFastVLine(i,    0, getHeight(), ((i*0x3F) << 2)      );
        }
        CyDelay(5000);
        
        for(i = 42; i > 0; i--)
        {   
            
            drawFastVLine(i+84, 0, getHeight(), ((i*0x3F) << (16+2)) | 0x00FCFC);
            drawFastVLine(i+42, 0, getHeight(), ((i*0x3F) << (8+2))  | 0xFC00FC);
            drawFastVLine(i,    0, getHeight(), ((i*0x3F) << 2)      | 0xFCFC00);
        }
        CyDelay(5000);
        
        char textB[] = "www.creativityslashdesign.tk ";
        
        fillScreen(BLACK);
        print("First words.", WHITE, BLACK, font_dim);
        y_start += 8;
        print("Second words.", WHITE, BLACK, font_dim);
        CyDelay(5000);
        
        fillScreen(RED);
        print(text, WHITE, BLACK, font_dim);
        x_start = 0;
        y_start = getHeight()/2;
        printN(textB, WHITE, BLACK, font_dim, 0);
        CyDelay(5000);
        
        RotSetting(1);
        fillScreen(RED);
        print(text, WHITE, BLACK, font_dim);
        x_start = 0;
        y_start = getHeight()/2;
        printN(textB, WHITE, BLACK, font_dim, 1);
        CyDelay(5000);
        
        RotSetting(2);
        fillScreen(RED);
        print(text, WHITE, BLACK, font_dim);
        x_start = 0;
        y_start = getHeight()/2;
        printN(textB, WHITE, BLACK, font_dim, 2);
        CyDelay(5000);
        
        RotSetting(3);
        fillScreen(RED);
        print(text, WHITE, BLACK, font_dim);
        x_start = 0;
        y_start = getHeight()/2;
        printN(textB, WHITE, BLACK, font_dim, 3);
        CyDelay(5000);
		
        RotSetting(0);
        
        //CySysPmSleep();
    }
}
